<?php
        class Aer
	{
		public $db;
		function __construct()
		{
			$hostname = "localhost";
			$dbname = "assignment";
			$username = "root";//Please change Username        
			$password = "root";//Please change Password
			$this->db = new PDO("mysql:host=$hostname;dbname=$dbname",$username,$password);
		}
		
		public function getEmployee($emp_name){
                        $chksql = "SELECT id, `employee_name`,`employee_salary`,`created_date`,`department_id` FROM employees WHERE employee_name LIKE '%$emp_name'";                        
                        $stmt = $this->db->prepare($chksql);
                        //$stmt->bindParam(':emp_name', $emp_name);
                        $stmt->execute();
                        if($stmt->rowCount() > 0){
                            $results = $stmt->fetchAll(PDO::FETCH_ASSOC);
                            foreach($results as $result){
                                //Get Department
                                $dsql = "SELECT department_name FROM department WHERE id = '$result[department_id]'";
                                $stmt = $this->db->prepare($dsql);
                                $stmt->execute();
                                $department_name = $stmt->fetch();
                                //Get Contact Details
                                $csql = "SELECT contact_number,emp_address FROM contact_details WHERE emp_id = '$result[id]'";
                                $stmt = $this->db->prepare($csql);
                                $stmt->execute();
                                $contact_details = $stmt->fetchAll(PDO::FETCH_ASSOC);
                                $emp_data = array_merge($results,$department_name,$contact_details);
                            }
                        }else{
                                return json_encode("No Match Found");
                        }
                        return $emp_data;
			
		}
                
                public function getAllEmployee(){
                        $chksql = "SELECT employees.id,employee_name, employee_salary,department_id, employees.created_date, updated_date,department_name FROM employees,department WHERE department_id=department.id";
                        //var_dump($chksql);
                        $stmt = $this->db->prepare($chksql);
                        $stmt->execute();
                        if($stmt->rowCount() > 0){
                            $results = $stmt->fetchAll(PDO::FETCH_ASSOC);
                            foreach($results as $result){
                                //Get Department
                                $dsql = "SELECT department_name FROM department WHERE id = '$result[department_id]'";
                                $stmt = $this->db->prepare($dsql);
                                $stmt->execute();
                                $department_name = $stmt->fetch();
                                //Get Contact Details
                                $csql = "SELECT emp_id,contact_number,emp_address FROM contact_details WHERE emp_id = '$result[id]'";
                                $stmt = $this->db->prepare($csql);
                                $stmt->execute();
                                $contact_details = $stmt->fetchAll(PDO::FETCH_ASSOC);
                                $emp_data[] = array_merge($results,$department_name,$contact_details);
                            }
                        }else{
                                return json_encode("No Match Found");
                        }
			return $emp_data;
		}                
		
                public function deleteEmployee($emp_id){
                        $sql = "DELETE `employees`,`contact_details` FROM `employees` INNER JOIN `contact_details` ON employees.id = contact_details.emp_id WHERE employees.id = '$emp_id'";
                        $stmt = $this->db->prepare($sql);
                        $result = $stmt->execute();
                        if($result){
                            return json_encode(array("200","Successful"));
                        }else{
                            return json_encode(array("400","Bad Request"));
                        }
                }
                
                public function addEmployee($emp_name,$emp_salary,$dept_id,$contact_details){
                        $datetime = date("Y-m-d H:i:s");
                        $sql = "INSERT INTO `employees`(`employee_name`,`employee_salary`, `department_id`, `created_date`, `updated_date`)"
                                . "VALUES (:ename,:esalary,:ed_id,:ecd,:eud)";
                                $stmt = $this->db->prepare($sql);
                                $stmt->bindValue(':ename', $emp_name);
                                $stmt->bindValue(':esalary', $emp_salary);
                                $stmt->bindValue(':ed_id', $dept_id);
                                $stmt->bindValue(':ecd', $datetime);
                                $stmt->bindValue(':eud', $datetime);
                                $result = $stmt->execute();
                                $id = $this->db->lastInsertId();
                                    $cadetails = explode("-", $contact_details);                                    
                                    foreach ($cadetails as $details){
                                        $cafdetails = explode(":", $details);
                                            if($cafdetails[0]=="contact"){
                                              $sql = "INSERT INTO `contact_details` (`emp_id`,`contact_number`,`created_date`,`emp_address`) VALUES ($id,$cafdetails[1],'$datetime','')";
                                              $stmt = $this->db->prepare($sql);
                                              $result = $stmt->execute();
                                            }
                                            if($cafdetails[0]=="address"){
                                              $sql = "UPDATE `contact_details` SET `emp_address` = '$cafdetails[1]' WHERE `emp_id` = '$id'";                                                
                                              $stmt = $this->db->prepare($sql);
                                              $result = $stmt->execute();
                                            }                                            
                                          }
                                if($result){
                                    return json_encode(array("200","Successful"));
                                }else{
                                    return json_encode(array("400","Bad Request"));
                                }
                }
                
                public function updateEmployee($emp_id,$emp_name,$emp_salary){
                        $datetime = date("Y-m-d H:i:s");
                        if(!empty($emp_name) && !empty($emp_salary)){
                            $sql = "UPDATE employees SET employee_name = '$emp_name',employee_salary = '$emp_salary',updated_date = '$datetime' WHERE id = '$emp_id'";
                            $stmt = $this->db->prepare($sql);
                            $result = $stmt->execute();
                        }elseif(!empty($emp_name) && empty($emp_salary)){
                            $sql = "UPDATE employees SET employee_name = '$emp_name','updated_date = '$datetime' WHERE id = '$emp_id'";
                            $stmt = $this->db->prepare($sql);
                            $result = $stmt->execute();
                        }elseif(empty($emp_name) && !empty($emp_salary)){
                            $sql = "UPDATE employees SET employee_salary = '$emp_salary','updated_date = '$datetime' WHERE id = '$emp_id'";
                            $stmt = $this->db->prepare($sql);
                            $result = $stmt->execute();
                        }
                        if($result){
                            return json_encode(array("200","Successful"));
                        }else{
                            return json_encode(array("400","Bad Request"));
                        }
                }
                
                public function addDepartment($department_name){
                        $datetime = date("Y-m-d H:i:s");
                        $sql = "INSERT INTO `department`(`department_name`, `created_date`)"
                                . "VALUES (:dname,:dcd)";
                                $stmt = $this->db->prepare($sql);
                                $stmt->bindValue(':dname', $department_name);
                                $stmt->bindValue(':dcd', $datetime);
                                $result = $stmt->execute();
                                if($result){
                                    return json_encode(array("200","Successful"));
                                }else{
                                    return json_encode(array("400","Bad Request"));
                                }
                }
		
	}
