<?php
ini_set("display_errors",1);
include('conn.php');
$obj = new Aer();
$method = $_SERVER['REQUEST_METHOD'];

if ($method === 'POST') {
    if($_POST['atype']=="add_employee"){
        echo $obj->addEmployee($_POST['employee_name'],$_POST['employee_salary'],$_POST['department_id'],$_POST['contact_details']);
    }elseif($_POST['atype']=="add_department"){
        echo $obj->addDepartment($_POST['department_name']);
    }elseif($_POST['atype']=="delete_employee"){
        echo $obj->deleteEmployee($_POST['emp_id']);
    }elseif($_POST['atype']=="update_employee"){
        echo $obj->updateEmployee($_POST['emp_id'],$_POST['emp_name'],$_POST['emp_salary']);
    }
    
}elseif($method === 'GET'){
    if(!empty($_GET['emp_type']=="search")){
        print_r($obj->getEmployee($_GET['employee_name']));
    }elseif(!empty($_GET['emp_type']=="all")){
        print_r($obj->getAllEmployee());
    }
}